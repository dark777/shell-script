#!/bin/bash

# Create variables and usefull functions:
. "$( dirname $0 )/ink-bash-base.sh"

# Make an usable structure:
startSvgParser

# Get color argument:
color="$( getArg --color "$@" )"

echo "$( getArg --id "$@" )" |
while read id; do
  
  getElementById "$id"   |
  setStyle fill "$color" |
  replaceElementById "$id"
  
done

# Write the SCG code for the STDOUT (where the Inkscape is waiting):
printSVG

# erase the temporary things:
endSvgParser
